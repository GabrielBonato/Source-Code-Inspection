package projetoimc;

import IMC.IMC;
import entities.Usuario;
import java.util.Scanner;

public class ProjetoIMC extends Usuario{
    public static void main(String[] args) {
    
        IMC um;
        Usuario usu = new Usuario();
        
        usu.setAltura(1);
        usu.setPeso(1);       
        Scanner sc = new Scanner(System.in);
        um = new IMC(usu.getPeso(), usu.getAltura());
        int opc = 1;
        
        do{
            while(usu.getPeso() <= 1){
                System.out.println("\nDigite seu peso: ");
                usu.setPeso(sc.nextDouble());
            }

            while(usu.getAltura() <= 1){
                System.out.println("Digite sua altura: (Ex: 1,80)");
                usu.setAltura(sc.nextDouble());
            }
            
           um.calculaIMC(usu.getPeso(), usu.getAltura());
           System.out.println(um.calculaIMC(usu.getPeso(), usu.getAltura()));
           um.imprime();
           
            System.out.println("\nDigite 1 para refazer o cálculo do IMC: ");
            opc = sc.nextInt();
            if(opc == 1){
                usu.setPeso(1);
                usu.setAltura(1);
            }
        }while (opc == 1);
    }    
}
