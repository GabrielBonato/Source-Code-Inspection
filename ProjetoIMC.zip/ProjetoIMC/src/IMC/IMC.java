package IMC;

import entities.Usuario;

public class IMC extends Usuario{
    private double imc;

    public IMC(double peso, double altura) {
        super(peso, altura);
    }

    public IMC(double imc, double peso, double altura) {
        super(peso, altura);
        this.imc = imc;
    }

    
    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        this.imc = imc;
    }
    
    public double calculaIMC(double peso, double altura){
        this.imc = peso / (altura*altura);
        return (this.imc);
    }
    
    public void imprime(){
        if(this.imc < 18.5){
            System.out.println("Abaixo do peso");
        }
        if((this.imc >= 18.5)&&(this.imc <25)){
            System.out.println("No peso normal");
        }
        if((this.imc >= 25)&&(this.imc <30)){
            System.out.println("Acima do peso");
        } 
        if(this.imc >= 30){
            System.out.println("Obeso");
        }
    }
}
